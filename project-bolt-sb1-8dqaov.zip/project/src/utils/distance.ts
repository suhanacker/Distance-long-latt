export type DistanceUnit = 'm' | 'km' | 'mi' | 'nm';

export const unitLabels: Record<DistanceUnit, string> = {
  m: 'Meters',
  km: 'Kilometers',
  mi: 'Miles',
  nm: 'Nautical Miles'
};

export function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number,
  unit: DistanceUnit
): number {
  const R = 6371000; // Earth's radius in meters
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const mDistance = R * c;
  
  switch (unit) {
    case 'km':
      return mDistance / 1000;
    case 'mi':
      return mDistance * 0.000621371;
    case 'nm':
      return mDistance * 0.000539957;
    default:
      return mDistance;
  }
}

function toRad(degrees: number): number {
  return degrees * (Math.PI / 180);
}