import React, { useState } from 'react';
import { Navigation, ArrowRight } from 'lucide-react';
import { calculateDistance, DistanceUnit } from './utils/distance';
import Map from './components/Map';
import CoordinateInput from './components/CoordinateInput';
import UnitSelector from './components/UnitSelector';
import DistanceResult from './components/DistanceResult';

function App() {
  const [coordinates, setCoordinates] = useState({
    lat1: '',
    lon1: '',
    lat2: '',
    lon2: '',
  });
  
  const [unit, setUnit] = useState<DistanceUnit>('m');
  const [distance, setDistance] = useState<number | null>(null);

  const handleCoordinateChange = (point: 'A' | 'B', type: 'lat' | 'lon', value: string) => {
    const key = `${type}${point === 'A' ? '1' : '2'}` as keyof typeof coordinates;
    setCoordinates(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleCalculate = () => {
    const coords = {
      lat1: parseFloat(coordinates.lat1) || 0,
      lon1: parseFloat(coordinates.lon1) || 0,
      lat2: parseFloat(coordinates.lat2) || 0,
      lon2: parseFloat(coordinates.lon2) || 0,
    };

    const result = calculateDistance(
      coords.lat1,
      coords.lon1,
      coords.lat2,
      coords.lon2,
      unit
    );
    setDistance(result);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Navigation className="w-12 h-12 text-indigo-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Geographic Distance Calculator
          </h1>
          <p className="text-lg text-gray-600">
            Calculate the precise distance between any two points on Earth
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
          <Map coordinates={{
            lat1: parseFloat(coordinates.lat1) || 0,
            lon1: parseFloat(coordinates.lon1) || 0,
            lat2: parseFloat(coordinates.lat2) || 0,
            lon2: parseFloat(coordinates.lon2) || 0,
          }} />
          
          <div className="grid md:grid-cols-2 gap-8 mt-8">
            <CoordinateInput
              label="Point A"
              point="A"
              values={{ lat: coordinates.lat1, lon: coordinates.lon1 }}
              onChange={(type, value) => handleCoordinateChange('A', type, value)}
            />
            <CoordinateInput
              label="Point B"
              point="B"
              values={{ lat: coordinates.lat2, lon: coordinates.lon2 }}
              onChange={(type, value) => handleCoordinateChange('B', type, value)}
            />
          </div>

          <div className="mt-8 flex flex-col items-center gap-4">
            <UnitSelector value={unit} onChange={setUnit} />

            <button
              onClick={handleCalculate}
              className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors duration-200"
            >
              Calculate Distance
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {distance !== null && (
            <DistanceResult distance={distance} unit={unit} />
          )}
        </div>

        <div className="text-center text-sm text-gray-500">
          <p>
            Uses the Haversine formula to calculate the great-circle distance
            between two points on a sphere
          </p>
        </div>
      </div>
    </div>
  );
}

export default App;