import React from 'react';
import { DistanceUnit, unitLabels } from '../utils/distance';

interface UnitSelectorProps {
  value: DistanceUnit;
  onChange: (value: DistanceUnit) => void;
}

export default function UnitSelector({ value, onChange }: UnitSelectorProps) {
  return (
    <div className="w-full max-w-xs">
      <label className="block text-sm font-medium text-gray-700 mb-1">
        Distance Unit
      </label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value as DistanceUnit)}
        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
      >
        {Object.entries(unitLabels).map(([value, label]) => (
          <option key={value} value={value}>
            {label}
          </option>
        ))}
      </select>
    </div>
  );
}