import React from 'react';
import { DistanceUnit, unitLabels } from '../utils/distance';

interface DistanceResultProps {
  distance: number;
  unit: DistanceUnit;
}

export default function DistanceResult({ distance, unit }: DistanceResultProps) {
  return (
    <div className="mt-8 text-center">
      <div className="inline-block px-6 py-3 bg-green-50 rounded-lg">
        <h3 className="text-sm font-medium text-green-800 mb-1">
          Distance
        </h3>
        <p className="text-2xl font-bold text-green-900">
          {distance.toFixed(2)} {unitLabels[unit]}
        </p>
      </div>
    </div>
  );
}