import React from 'react';

interface CoordinateInputProps {
  label: string;
  point: 'A' | 'B';
  values: {
    lat: string;
    lon: string;
  };
  onChange: (type: 'lat' | 'lon', value: string) => void;
}

export default function CoordinateInput({ label, point, values, onChange }: CoordinateInputProps) {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
        <span className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center">
          {point}
        </span>
        {label}
      </h2>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Latitude
          </label>
          <input
            type="number"
            step="any"
            value={values.lat}
            onChange={(e) => onChange('lat', e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="Enter latitude"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Longitude
          </label>
          <input
            type="number"
            step="any"
            value={values.lon}
            onChange={(e) => onChange('lon', e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="Enter longitude"
          />
        </div>
      </div>
    </div>
  );
}