import React from 'react';
import { MapPin } from 'lucide-react';

interface MapProps {
  coordinates: {
    lat1: number;
    lon1: number;
    lat2: number;
    lon2: number;
  };
}

export default function Map({ coordinates }: MapProps) {
  const { lat1, lon1, lat2, lon2 } = coordinates;
  
  return (
    <div className="relative w-full h-[300px] bg-blue-50 rounded-lg overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1524661135-423995f22d0b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80')] bg-cover bg-center opacity-40" />
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="flex items-center gap-4">
          <MapPin className="w-6 h-6 text-red-500" />
          <div className="w-32 h-0.5 bg-red-500" />
          <MapPin className="w-6 h-6 text-red-500" />
        </div>
      </div>
    </div>
  );
}